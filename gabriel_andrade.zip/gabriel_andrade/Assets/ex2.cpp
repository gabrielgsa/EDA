                // Código base para os códigos com SDL //
#include "ilpgame.h"
#include <string>
using namespace std;
#define Max 6

TTF_Font *font;
SDL_Color whiteColor = {255, 255, 255, 255};
SDL_Surface *hero;
SDL_Surface *coin[Max];
int pontos = 0;
string contador = "Pontuacao : ";
string ponto = "0";

typedef struct Position {
	SDL_Surface* surface;
	int x;
	int y;
	bool colidiu;
	int coletou;
} position;

position heroi;
position moeda[Max];

void startMoeda(int i) {
	moeda[i].x = rand() % 800;
	moeda[i].y = rand() % 600;
}

void init() {
	srand(time(NULL));
	heroi.x = 0;
	heroi.y = 300;

	hero = loadImage("hero.png");
	for (int i = 0; i < Max; i++) {
		coin[i] = loadImage("coin.gif");
	}
	font = loadFont("FreeSans.ttf", 40);
	for (int i = 0; i < Max; i++) {
		startMoeda(i);
	}
	for (int i = 0; i < Max; i++) {
		moeda[i].coletou = 0;
	}
}

void coletaMoeda(int i) {
		int ax1 = heroi.x,
		ay1 = heroi.y,
		ax2 = heroi.x + 16,
		ay2 = heroi.y + 16;
	int bx1 = moeda[i].x,
	    by1 = moeda[i].y,
		bx2 = moeda[i].x + 16,
		by2 = moeda[i].y + 16;
	
		if (ax1 > bx2 || ay1 > by2 || ax2 < bx1 || ay2 < by1) {
			moeda[i].colidiu = false;
		}
		else {
			moeda[i].colidiu = true;
			moeda[i].coletou = 1;
			pontos += 1;
		}
		
}

void destroy() {

}
                // Eventos com teclado/mouse //
void processEvent(SDL_Event event) {
	SDL_Keycode keycode;
	if (isQuitEvent(event)) {
		endGameLoop();
	} else if (event.type == SDL_KEYDOWN) {
		keycode = event.key.keysym.sym;
		// Comandos para andar sem fugir da tela //
		if (keycode == SDLK_RIGHT) {
				heroi.x += 10;                
                if (heroi.x >= 800){
                heroi.x = 0; 
			} 
		}
			if (keycode == SDLK_LEFT) {
				heroi.x -= 10;                
                if (heroi.x <= 0){
                heroi.x = 790; 
			}
		}
			if (keycode == SDLK_UP) {
				heroi.y -= 10;                
                if (heroi.y <= 0) {
                heroi.y = 590; 
			}
		}
			if (keycode == SDLK_DOWN) {
				heroi.y += 10;
                if (heroi.y >= 600){
                heroi.y = 0; 
			}
		}			
	}
}

void update() {
	for (int a = 0; a < Max; a++) {
		coletaMoeda(a);

	}
	/*ponto = pontos;*/
	contador = "Pontuacao : ";
}
                // Função que desenha/print //
void draw() {
	drawText(contador, font, whiteColor, 350 , 40);
	drawText(ponto, font, whiteColor, 450 , 40);
	drawImage(hero, heroi.x, heroi.y);
	for (int i = 0; i < Max; i++) {
		if (moeda[i].coletou == 0){
			drawImage(coin[i], moeda[i].x, moeda[i].y);
		}
	}
}

int main(int argc, char *argv[]) {
	initSDL();
	gameLoop();

	return 0;
}
