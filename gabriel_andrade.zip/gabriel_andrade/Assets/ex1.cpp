#include "ilpgame.h"
using namespace std;
#define Max 4

// Surfaces //
SDL_Surface *hero;
SDL_Surface *block[Max];

typedef struct Position {
	SDL_Surface* surface;
	int x;
	int y;
	bool colidiu;
} position;

position bloco[Max];
position heroi;

void StartBlock(int z){

	bloco[z].x = rand() % 800;
	bloco[z].y = rand() % 600;

}



void init() {

	srand(time(NULL));
	heroi.x = 0;
	heroi.y = 300 ;

	hero = loadImage("hero.png");

    for (int i = 0; i < Max; i++) {
    	block[i] = loadImage("brick.png");
    }

	for (int q = 0; q < Max; q++) {
		StartBlock(q);
	}
}

void destroy() {


}

void processEvent(SDL_Event event) {
	SDL_Keycode keycode;
	if (isQuitEvent(event)) {
		endGameLoop();
	} else if (event.type == SDL_KEYDOWN) {
		keycode = event.key.keysym.sym;

			if (keycode == SDLK_RIGHT) {
				heroi.x += 10;                
                if (heroi.x >= 800){
                heroi.x = 0; 
			} 
		}
			if (keycode == SDLK_LEFT) {
				heroi.x -= 10;                
                if (heroi.x <= 0){
                heroi.x = 790; 
			}
		}
			if (keycode == SDLK_UP) {
				heroi.y -= 10;                
                if (heroi.y <= 0) {
                heroi.y = 590; 
			}
		}
			if (keycode == SDLK_DOWN) {
				heroi.y += 10;
                if (heroi.y >= 600){
                heroi.y = 0; 
			}
		}			
	}
}

void ColisaoBlock(int i) {

	int ax1 = heroi.x,
		ay1 = heroi.y,
		ax2 = heroi.x + 16,
		ay2 = heroi.y + 16;
	int bx1 = bloco[i].x,
	    by1 = bloco[i].y,
		bx2 = bloco[i].x + 16,
		by2 = bloco[i].y + 16;
	
		if (ax1 > bx2 || ay1 > by2 || ax2 < bx1 || ay2 < by1) {
			bloco[i].colidiu = false;
		}
		else {
			heroi.x = 0;
			heroi.y = 300;
		}
}

void update() {

	for (int i = 0; i < Max; i++) {
	ColisaoBlock(i);
	}

}

void draw() {

	drawImage(hero, heroi.x, heroi.y);
	for(int z = 0; z < Max; z++){
		drawImage(block[z], bloco[z].x, bloco[z].y);
	}
}

int main(int argc, char *argv[]) {
	initSDL();
	gameLoop();

	return 0;
}