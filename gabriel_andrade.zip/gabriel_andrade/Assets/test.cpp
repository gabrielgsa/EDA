#include "ilpgame.h"
using namespace std;

int herox = 0;
int heroy = 200 ;
SDL_Surface *hero;


void init() {

	hero = loadImage("hero.png");

}

void destroy() {


}

void processEvent(SDL_Event event) {
	SDL_Keycode keycode;
	if (isQuitEvent(event)) {
		endGameLoop();
	} else if (event.type == SDL_KEYDOWN) {
		keycode = event.key.keysym.sym;
			if (keycode == SDLK_RIGHT) {
				herox += 10;
                /*
                if (herox >= 800){
                herox = 790; */
			}
			if (keycode == SDLK_LEFT) {
				herox -= 10;
                /*
                if (herox <= 0){
                herox = 0; */
			}
			if (keycode == SDLK_UP) {
				heroy -= 10;
                /*
                if (heroy <= 0){
                heroy = 0; */
			}
			if (keycode == SDLK_DOWN) {
				heroy += 10;
                /*
                if (heroy>= 600){
                heroy = 590; */
			}
			
	}

}


void update() {


}

void draw() {

	drawImage(hero, herox, heroy);

}

int main(int argc, char *argv[]) {
	initSDL();
	gameLoop();

	return 0;
}
